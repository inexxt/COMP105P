#include "phase1.map.h"

int findFastest();
void goSubOptimal(Queue** a);