#include "defines.h"

void turnByAngleDegree(double angle);
void goStraight(double distance);