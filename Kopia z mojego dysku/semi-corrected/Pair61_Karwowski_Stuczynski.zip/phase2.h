#include "findFastest.h"
#include "cuttingCorners.h"

void goOptimal();
Queue* calculateShortestPath();
void optimizeQueue(Queue** oP);
void goWithCutting(Queue** a);