#include "phase1.move.h"

void goSubOptimal(Queue** a);