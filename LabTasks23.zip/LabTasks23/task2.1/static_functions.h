#include <stdio.h>
#include <stdlib.h>
#include "picomms.h"
#include <math.h>

void turn(int degrees);
void straight(double length);

