#include "phase1.h"

void goToXY(XY destination);
void centerStartingPosition();
void correctPosition(XY current);
void endPhase1();

